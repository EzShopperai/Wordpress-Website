<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Animation_Headline extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Animation Headline', 'sasby-core' );
		$this->rt_base = 'rt-animation-headline';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'Section Title', 'sasby-core' ),
			),
			/*title layout*/
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'    => 'responsive',
				'label'   => esc_html__( 'Alignment', 'sasby-core' ),
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'sasby-core' ),
				'default' => 'Welcome To Sasby',
			),
			array(
				'type'    => Controls_Manager::WYSIWYG,
				'id'      => 'content',
				'label'   => esc_html__( 'Animation Text', 'sasby-core' ),
			),
			array(
				'type' => Controls_Manager::SELECT,
				'id'      => 'heading_size',
				'label'   => esc_html__( 'HTML Tag', 'sasby-core' ),
				'options' => array(
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				),
				'default' => 'h2',
			),
			array(
				'mode' => 'section_end',
			),

			/*title section*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Title', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-animated-headline .heading-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-animated-headline .heading-title' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'animation_title_color',
				'label'   => esc_html__( 'Animation Title Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-animated-headline .ah-words-wrapper p' => 'color: {{VALUE}}',
				),
			),
			array(
				'mode' => 'section_end',
			),

			// Animation style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_animation_style',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'sasby-core' ),
					'hide'        => esc_html__( 'Off', 'sasby-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'sasby-core' ),
				'options' => array(
					'none' => esc_html__( 'none', 'sasby-core' ),
					'bounce' => esc_html__( 'bounce', 'sasby-core' ),
					'flash' => esc_html__( 'flash', 'sasby-core' ),
					'pulse' => esc_html__( 'pulse', 'sasby-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'sasby-core' ),
					'shakeX' => esc_html__( 'shakeX', 'sasby-core' ),
					'shakeY' => esc_html__( 'shakeY', 'sasby-core' ),
					'headShake' => esc_html__( 'headShake', 'sasby-core' ),
					'swing' => esc_html__( 'swing', 'sasby-core' ),
					'fadeIn' => esc_html__( 'fadeIn', 'sasby-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'sasby-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'sasby-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'sasby-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'sasby-core' ),
					'bounceIn' => esc_html__( 'bounceIn', 'sasby-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'sasby-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'sasby-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'sasby-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'sasby-core' ),
					'slideInDown' => esc_html__( 'slideInDown', 'sasby-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'sasby-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'sasby-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'sasby-core' ),
				),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),

		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		$template = 'rt-animation-headline';
		return $this->rt_template( $template, $data );
	}
}