<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Group_Control_Image_Size;
// image
$getimg = Group_Control_Image_Size::get_attachment_image_html($data, 'icon_image_size', 'video_image');
?>
<div class="scroll-down">
	<div class="scroll">
		<a href="<?php echo esc_url($data['sec_id']['url']); ?>">
			<?php if (!empty($getimg)) { ?>
				<?php echo wp_kses_post($getimg); ?>
			<?php } else { ?>
				<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M11.6501 14.6001L14.8501 17.8001L18.0501 14.6001" stroke="currentColor" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
					<path d="M14.8499 5V17.7125" stroke="currentColor" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
					<path d="M25 15.2251C25 20.7501 21.25 25.2251 15 25.2251C8.75 25.2251 5 20.7501 5 15.2251" stroke="currentColor" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
				</svg>
			<?php } ?>
		</a>
	</div>
</div>