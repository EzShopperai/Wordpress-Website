<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use SasbyTheme;
use SasbyTheme_Helper;
use \WP_Query;

$thumb_size  = 'sasby-size3';

if (get_query_var('paged')) {
	$paged = get_query_var('paged');
} else if (get_query_var('page')) {
	$paged = get_query_var('page');
} else {
	$paged = 1;
}

$args = array(
	'post_type'      	=> 'sasby_portfolio',
	'posts_per_page' 	=> $data['number'],
	'order' 			=> $data['post_ordering'],
	'orderby' 			=> $data['post_orderby'],
	'paged' 			=> $paged
);

if (!empty($data['cat'])) {
	$args['tax_query'] = array(
		array(
			'taxonomy' => 'sasby_portfolio_category',
			'field' => 'term_id',
			'terms' => $data['cat'],
		)
	);
}

$query = new WP_Query($args);
$temp = SasbyTheme_Helper::wp_set_temp_query($query);
$col_class = "col-xl-{$data['col_xl']} col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-xs-{$data['col_xs']}";
?>
<div class="rt-portfolio-default rt-portfolio-multi-layout-1 portfolio-grid-<?php echo esc_attr($data['style']); ?>">
	<div class="row <?php echo esc_attr($data['item_space']); ?>">
		<?php $m = $data['delay'];
		$n = $data['duration'];
		if ($query->have_posts()) {
			while ($query->have_posts()) {
				$query->the_post();
				$id         = get_the_id();
				$logo_image   	= get_post_meta($id, 'portfolio_logo', true);
				$icon_id        = wp_get_attachment_image_src($logo_image, 'full');
				$sasby_portfolio_bgc   	= get_post_meta($id, 'sasby_portfolio_bgc', true);
				if ($data['contype'] == 'content') {
					$content = apply_filters('the_content', get_the_content());
				} else {
					$content = apply_filters('the_excerpt', get_the_excerpt());;
				}
				$content = wp_trim_words($content, $data['count'], '');
				$content = $content;
				$bg_color = (!empty($sasby_portfolio_bgc)) ? esc_attr($sasby_portfolio_bgc) : "#ffffff";
		?>

            <div class="<?php echo esc_attr($col_class); ?> <?php echo esc_attr($data['animation']); ?> <?php echo esc_attr($data['animation_effect']); ?>" data-wow-delay="<?php echo esc_attr($m); ?>s" data-wow-duration="<?php echo esc_attr($n); ?>s">
                <div class="portfolio-box-3">
                    <div class="item-img">
                        <a href="<?php the_permalink(); ?>" aria-label="Portfolio">
		                    <?php
		                    if (has_post_thumbnail()) {
			                    the_post_thumbnail($thumb_size);
		                    } else {
			                    if (!empty(SasbyTheme::$options['no_preview_image']['id'])) {
				                    echo wp_get_attachment_image(SasbyTheme::$options['no_preview_image']['id'], 'full');
			                    } else {
				                    echo '<img class="wp-post-image" src="' . SasbyTheme_Helper::get_img('noimage_470X555.jpg') . '" alt="' . get_the_title() . '" loading="lazy" >';
			                    }
		                    }
		                    ?>
                        </a>
                    </div>
                    <div class="content">
                        <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
	                    <?php if ($data['content_display']  == 'yes') { ?>
                            <p><?php echo wp_kses($content, 'alltext_allow'); ?></p>
	                    <?php } ?>
                        <?php if($data['view_on_of'] == 'on'){?>
                            <div class="post-btn"><a href="<?php the_permalink();?>"><?php echo esc_html($data['view_text']); ?></a></div>
                        <?php } ?>
                    </div>
                </div>
            </div>

			<?php $m = $m + 0.2;
				$n = $n + 0.1;
			} ?>
		<?php } ?>
	</div>
	<?php if ($data['more_button'] == 'show') { ?>
		<?php if (!empty($data['see_button_text'])) { ?>
			<div class="portfolio-button"><a class="button-style-2 btn-common" aria-label="Portfolio" href="<?php echo esc_url($data['see_button_link']); ?>"><span><?php echo esc_html($data['see_button_text']); ?></span></a></div>
		<?php } ?>
	<?php } else { ?>
		<?php SasbyTheme_Helper::pagination(); ?>
	<?php } ?>
	<?php SasbyTheme_Helper::wp_reset_temp_query($temp); ?>
</div>