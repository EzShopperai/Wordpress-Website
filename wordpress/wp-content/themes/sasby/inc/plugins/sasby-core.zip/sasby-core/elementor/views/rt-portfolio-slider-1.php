<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
use SasbyTheme;
use SasbyTheme_Helper;
use \WP_Query;

$thumb_size  = 'sasby-size3';

$args = array(
	'post_type'      	=> 'sasby_portfolio',
	'posts_per_page' 	=> $data['number'],
	'order' 			=> $data['post_ordering'],
	'orderby' 			=> $data['post_orderby'],
);

if ( !empty( $data['cat'] ) ) {
	$args['tax_query'] = array(
		array(
			'taxonomy' => 'sasby_portfolio_category',
			'field' => 'term_id',
			'terms' => $data['cat'],
		)
	);
}

$query = new WP_Query( $args );

?>
<div class="rt-portfolio-default rt-portfolio-multi-layout-1 portfolio-grid-<?php echo esc_attr($data['style']); ?> <?php echo esc_attr( $data['nav_position'] ) ?>">
    <div class="rt-swiper-slider swiper-slider rt-swiper-nav" data-xld ="<?php echo esc_attr( $data['swiper_data'] );?>">
        <div class="swiper-wrapper">
			<?php $m = $data['delay']; $n = $data['duration'];
			if ( $query->have_posts() ) :?>
				<?php while ( $query->have_posts() ) : $query->the_post();?>
					<?php
					$id            	= get_the_id();
					if ( $data['contype'] == 'content' ) {
						$content = apply_filters( 'the_content', get_the_content() );
					}
					else {
						$content = apply_filters( 'the_excerpt', get_the_excerpt() );;
					}
					$content = wp_trim_words( $content, $data['count'], '' );
					$content = "$content";
					?>
                    <div class="swiper-slide <?php echo esc_attr( $data['animation'] );?> <?php echo esc_attr( $data['animation_effect'] );?>" data-wow-delay="<?php echo esc_attr( $m );?>s" data-wow-duration="<?php echo esc_attr( $n );?>s">
                        <div class="portfolio-box-3">
                            <div class="item-img">
                                <a href="<?php the_permalink(); ?>" aria-label="Portfolio">
									<?php
									if (has_post_thumbnail()) {
										the_post_thumbnail($thumb_size);
									} else {
										if (!empty(SasbyTheme::$options['no_preview_image']['id'])) {
											echo wp_get_attachment_image(SasbyTheme::$options['no_preview_image']['id'], 'full');
										} else {
											echo '<img class="wp-post-image" src="' . SasbyTheme_Helper::get_img('noimage_470X555.jpg') . '" alt="' . get_the_title() . '" loading="lazy" >';
										}
									}
									?>
                                </a>
                            </div>
                            <div class="content">
                                <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
								<?php if ($data['content_display']  == 'yes') { ?>
                                    <p><?php echo wp_kses($content, 'alltext_allow'); ?></p>
								<?php } ?>
								<?php if($data['view_on_of'] == 'on'){?>
                                    <div class="post-btn"><a href="<?php the_permalink();?>"><?php echo esc_html($data['view_text']); ?></a></div>
								<?php } ?>
                            </div>
                        </div>
                    </div>
					<?php $m = $m + 0.2; $n = $n + 0.1; endwhile;?>
			<?php endif;?>
			<?php wp_reset_postdata();?>
        </div>
		<?php if($data['display_arrow']=='yes'){  ?>
            <div class="swiper-navigation">
                <div class="swiper-button-prev"><i class="fa-solid fa-angle-left"></i></div>
                <div class="swiper-button-next"><i class="fa-solid fa-angle-right"></i></div>
            </div>
		<?php } if($data['display_buttet']=='yes') { ?>
            <div class="swiper-pagination"></div>
		<?php } ?>
    </div>
</div>