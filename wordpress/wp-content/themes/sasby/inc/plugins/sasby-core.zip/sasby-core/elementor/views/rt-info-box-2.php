<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;

extract($data);

$attr = '';
if (!empty($data['buttonurl']['url'])) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty($data['buttonurl']['is_external']) ? ' target="_blank"' : '';
	$attr .= !empty($data['buttonurl']['nofollow']) ? ' rel="nofollow"' : '';
	$title = '<a ' . $attr . '>' . $data['title'] . '</a>';
} else {
	$title = $data['title'];
}

//Icon, image
if ($attr) {
	$getimg = '<a ' . $attr . '>' . Group_Control_Image_Size::get_attachment_image_html($data, 'icon_image_size', 'icon_image') . '</a>';
} else {
	$getimg = Group_Control_Image_Size::get_attachment_image_html($data, 'icon_image_size', 'icon_image');
}

$final_icon_class       = " fas fa-thumbs-up";
$final_icon_image_url   = '';
if (is_string($icon_class['value']) && $dynamic_icon_class =  $icon_class['value']) {
	$final_icon_class     = $dynamic_icon_class;
}
if (is_array($icon_class['value'])) {
	$final_icon_image_url = $icon_class['value']['url'];
}
?>
<div class="rt-info-box rt-feature-box-2 <?php echo esc_attr($data['animation']); ?> <?php echo esc_attr($data['animation_effect']); ?>" data-wow-delay="<?php echo esc_attr($data['delay']); ?>s" data-wow-duration="<?php echo esc_attr($data['duration']); ?>s">
	<?php
		if (!empty($data['icontype']) && $data['icontype'] == 'image') {
			echo '<div class="rt-icon">' . wp_kses_post($getimg) . '</div>';
		} elseif ($data['icon_class']) {
			echo '<div class="rt-icon">';
			Icons_Manager::render_icon($data['icon_class']);
			echo '</div>';
		} else {
			echo '<div class="rt-icon"><i>' . esc_attr($final_icon_class) . '</i></div>';
		}
	?>
	<?php if (!empty($data['title'])) { ?>
		<h3 class="rt-title"><?php echo wp_kses_post($title); ?></h3>
	<?php }
	if (!empty($data['content'])) { ?>
		<div class="rt-text"><?php echo wp_kses_post($data['content']); ?></div>
	<?php } ?>
	<?php if (!empty($data['buttontext'] && $data['button_display'] == 'yes')) { ?>
        <div class="rt-button sasby-button">
            <a href="<?php echo esc_url($data['buttonurl']['url']); ?>" class="btn-common rt-btn-style">
	            <?php echo wp_kses_post($data['buttontext']);  ?>
                <?php if($data['btn_icon']){ ?>
                    <span class="rt-btn-icon"><?php Icons_Manager::render_icon($data['btn_icon']); ?></span>
                <?php } ?>
            </a>
        </div>
	<?php } ?>
</div>