<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Scroll_Down extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Scroll Down', 'sasby-core' );
		$this->rt_base = 'rt-scroll-down';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'video_image',
				'label'   => esc_html__('Image', 'sasby-core'),
				'description' => esc_html__('Icon image', 'sasby-core'),
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'sec_id',
				'label'   => esc_html__( 'Section ID', 'sasby-core' ),
				'placeholder' => '#',
			),	
			array(
				'mode' => 'section_end',
			),
			/*Box section*/
		);
		return $fields;
	}

	protected function render()
	{
		$data = $this->get_settings();
		$template = 'rt-scroll-down';
		return $this->rt_template($template, $data);
	}
}