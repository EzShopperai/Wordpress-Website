<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
?>
<div class="rt-animated-headline">
    <div class="heading-title ah-headline wow animate__fadeInUp position-relative" data-wow-delay=".2s" data-wow-duration="1s">
        <span><?php echo wp_kses_post( $data['title'] ); ?></span>
        <div class="ah-words-wrapper">
              <?php echo wp_kses_post( $data['content'] );?>
        </div>
    </div>
</div>
