<?php
namespace radiustheme\Sasby_Core;
use \RT_Posts;
use SasbyTheme;
class PostTypeController {
	public static $instance = null;
	public $post_type;
	public function __construct() {
		if ( defined( 'RT_FRAMEWORK_VERSION' ) ) {
			$this->post_type = RT_Posts::getInstance();
			$this->register_custom_post_type();
			$this->register_custom_taxonomy();
		}
	}
	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register custom post type
	 * @return void
	 */
	private function register_custom_post_type() {
		$custom_posts = [
			[
				'id'            => 'sasby_team',
				'slug'          => ! empty(SasbyTheme::$options['team_slug']) ? SasbyTheme::$options['team_slug'] : 'team',
				'singular'      => 'Team',
				'plural'        => 'Teams',
				'menu_icon'     => 'dashicons-businessman',
				'menu_position' => 18,
				'supports'      => [ 'title', 'editor', 'thumbnail', 'excerpt', 'author', 'comments' ],
				'description'   => 'Teams Custom Post Type',
			],
			[
				'id'            => 'sasby_portfolio',
				'slug'          => ! empty(SasbyTheme::$options['portfolio_slug']) ? SasbyTheme::$options['portfolio_slug'] : 'portfolio',
				'singular'      => 'Portfolio',
				'plural'        => 'Portfolios',
				'menu_icon'     => 'dashicons-book',
				'menu_position' => 18,
				'supports'      => [ 'title', 'editor', 'thumbnail', 'page-attributes' ],
				'description'   => 'Portfolio Custom Post Type',
			]
		];

		$this->post_type->add_post_types( $custom_posts );
	}

	/**
	 * Register custom taxonomy
	 * @return void
	 */
	private function register_custom_taxonomy() {
		$custom_posts = [
			[
				'id'        => 'sasby_team_category',
				'post_type' => [ 'sasby_team' ],
				'slug'      => !empty(SasbyTheme::$options['team_cat_slug']) ? SasbyTheme::$options['team_cat_slug'] : 'team_cat_slug',
				'singular'  => 'Team Category',
				'plural'    => 'Team Categories',
			],
			[
				'id'        => 'sasby_portfolio_category',
				'post_type' => [ 'sasby_portfolio' ],
				'slug'      => !empty(SasbyTheme::$options['portfolio_cat_slug']) ? SasbyTheme::$options['portfolio_cat_slug'] : 'portfolio_cat_slug',
				'singular'  => 'Portfolio Category',
				'plural'    => 'Portfolio Categories',
			]
		];

		$this->post_type->add_taxonomies( $custom_posts );
	}
}

PostTypeController::getInstance();
