<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Info_Box extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Info Box', 'sasby-core' );
		$this->rt_base = 'rt-info-box';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'sasby-core' ),
				'options' => array(
					'style1' => esc_html__( 'Info Style 1', 'sasby-core' ),
					'style2' => esc_html__( 'Info Style 2', 'sasby-core' ),
					'style3' => esc_html__( 'Info Style 3', 'sasby-core' ),
					'style4' => esc_html__( 'Info Style 4', 'sasby-core' ),
					'style5' => esc_html__( 'Info Style 5', 'sasby-core' ),
					'style6' => esc_html__( 'Info Style 6', 'sasby-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'	  => 'responsive',
				'label'   => esc_html__( 'Alignment', 'sasby-core' ),
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			),
			/*Icon Start*/
			array(					 
			   'type'    => Controls_Manager::CHOOSE,
			   'options' => array(
			     'icon' => array(
			       'title' => esc_html__( 'Left', 'sasby-core' ),
			       'icon' => 'fa fa-smile',
			     ),
			     'image' => array(
			       'title' => esc_html__( 'Center', 'sasby-core' ),
			       'icon' => 'fa fa-image',
			     ),		     
			   ),
			   'id'      => 'icontype',
			   'label'   => esc_html__( 'Media Type', 'sasby-core' ),
			   'default' => 'icon',
			   'label_block' => false,
			   'toggle' => false,
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'icon_class',
				'label'   => esc_html__( 'Icon', 'sasby-core' ),
				'default' => array(
			      'value' => 'fas fa-smile-wink',
			      'library' => 'fa-solid',
				),	
			  	'condition'   => array('icontype' => array( 'icon' ) ),
			),	
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'icon_image',
				'label'   => esc_html__( 'Image', 'sasby-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'sasby-core' ),
				'condition'   => array('icontype' => array( 'image' ) ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'sasby-core' ),	
				'name' => 'icon_image_size', 
				'separator' => 'none',		
				'condition'   => array('icontype' => array( 'image' ) ),
			),			
			/*Icon end*/
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'sasby-core' ),
				'default' => esc_html__( 'Web Development', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'count_number',
				'label'   => esc_html__( 'Number', 'sasby-core' ),
				'default' => esc_html__( '01', 'sasby-core' ),
				'condition'   => array( 'style' => array( 'style7' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'count_year',
				'label'   => esc_html__( 'Year', 'sasby-core' ),
				'default' => esc_html__( '2017', 'sasby-core' ),
				'condition'   => array( 'style' => array( 'style9' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'sasby-core' ),
				'default' => esc_html__('Lorem ipsum dolor consectetur at adipiscing elit. Mauris nullam integer quam dolor.', 'sasby-core' ),
				'condition'   => array( 'style!' => array( 'style9' ) ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'button_display',
				'label'       => esc_html__( 'Button Display', 'sasby-core' ),
				'label_on'    => esc_html__( 'On', 'sasby-core' ),
				'label_off'   => esc_html__( 'Off', 'sasby-core' ),
				'default'     => 'no',
				'description' => esc_html__( 'Show or Hide Content. Default: off', 'sasby-core' ),
				'condition'   => array( 'style' => array('style1', 'style2',  'style5', 'style6',  'style7', 'style8', 'style9' ) ),
			),			
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'sasby-core' ),
				'default' => esc_html__( 'Read More', 'sasby-core' ),
				'condition'   => array( 'button_display' => array( 'yes' ) ),
			),
			array(
				'type'  => Controls_Manager::URL,
				'id'    => 'buttonurl',
				'label' => esc_html__( 'Title Link (Optional)', 'sasby-core' ),
				'placeholder' => '#',
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'btn_icon',
				'label'   => esc_html__( 'Icon', 'sasby-core' ),
				'default' => array(
					'value' => 'fas fa-smile-wink',
					'library' => 'fa-solid',
				),
				'condition'   => array( 'style' => array('style2') ),
			),
			array(
				'mode' => 'section_end',
			),			
			/*Style Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_box',
				'label'   => esc_html__( 'Box Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'box_bg_color',
				'label'   => esc_html__( 'Box Background Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'box_bg_hover_color',
				'label'   => esc_html__('Box Hover Background Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box:hover' => 'background-color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_padding',
	            'label'   => __( 'Box Padding', 'sasby-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-info-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                    
	            ),
	            'separator' => 'before',
	        ),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_radius',
	            'label'   => __( 'Box Radius', 'sasby-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-info-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                    
	            ),
	        ),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'hover_animation',
				'label'       => esc_html__( 'Hover Animation', 'sasby-core' ),
				'label_on'    => esc_html__( 'Show', 'sasby-core' ),
				'label_off'   => esc_html__( 'Hide', 'sasby-core' ),
				'default'     => 'yes',
				'condition'   => array( 'style' => array( 'style1', 'style3', 'style5' ) ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'active_hover',
				'label'       => esc_html__( 'Active Hover Animation', 'sasby-core' ),
				'label_on'    => esc_html__( 'Show', 'sasby-core' ),
				'label_off'   => esc_html__( 'Hide', 'sasby-core' ),
				'default'     => 'no',
				'condition'   => array( 'hover_animation' => array( 'yes' ), 'style' => array( 'style1', 'style3', 'style5' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'border_color6',
				'label'   => esc_html__('Box Border Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style6' => 'border-color: {{VALUE}}',
				),
				'condition'   => array('style' => array('yes'), 'style' => array('style6')),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'border_hover_color6',
				'label'   => esc_html__('Box Border Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style6:hover' => 'border-color: {{VALUE}}',
				),
				'condition'   => array('style' => array('yes'), 'style' => array('style6')),
			),
			array(
				'id'        => 'rt_box_shadow',
				'mode'      => 'group',
				'type'      => \Elementor\Group_Control_Box_Shadow::get_type(),
				'label'     => esc_html__( 'Box Shadow Color', 'sasby-core' ),
				'name'      => 'box_shadow',
				'selector' => '{{WRAPPER}} .rt-info-box',
			),
			array(
				'mode'    => 'group',
				'type'    => \Elementor\Group_Control_Border::get_type(),
				'name'    => 'box_border',
				'label'   => esc_html__( 'Border', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-info-box',
			),
			array(
				'type'    => Controls_Manager::HEADING,
				'id'      => 'title_hover_border',
				'label'   => esc_html__( 'Border Hover', 'sasby-core' ),
			),
			array(
				'mode'    => 'group',
				'type'    => \Elementor\Group_Control_Border::get_type(),
				'name'    => 'box_border_hover',
				'label'   => esc_html__( 'Hover Border', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-info-box:hover',
			),
			array(
				'mode' => 'section_end',
			),

			/*Title Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Title Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-info-box .rt-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box .rt-title a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_hover_color',
				'label'   => esc_html__( 'Title Hover Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box:not(.rt-feature-box-2,.rt-info-style5) .rt-title a:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-feature-box-2:hover .rt-title a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-style5:hover .rt-title a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'title_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Title Space', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-info-box .rt-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'mode' => 'section_end',
			),
			
			// Content style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_text_title',
				'label'   => esc_html__( 'Content Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),			
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'content_typo',
				'label'   => esc_html__( 'Content Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-info-box .rt-text',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'conent_color',
				'label'   => esc_html__( 'Content Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-text' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'conent_hover_color',
				'label'   => esc_html__( 'Content Hover Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box:hover .rt-text' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'content_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Content Space', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-info-box .rt-text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			),	
			array(
				'mode' => 'section_end',
			),			
			// Icon style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_icon',
				'label'   => esc_html__( 'Icon Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),			
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'icon_size',
				'label'   => esc_html__( 'Icon Size', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-icon' => 'font-size: {{VALUE}}px',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_color',
				'label'   => esc_html__( 'Icon Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box:not(.rt-feature-box-2) .rt-icon path' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box .rt-icon path' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box .rt-icon svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box .rt-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-style5 .rt-icon path' => 'stroke: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_bg_color',
				'label'   => esc_html__('Icon BG Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style4 .round-shape svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box .rt-icon' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_hover_color',
				'label'   => esc_html__( 'Icon Hover Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style5:hover .rt-icon path' => 'stroke: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box:hover .rt-icon path' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box:hover .rt-icon svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box:hover .rt-icon' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_bg_hover_color',
				'label'   => esc_html__('Icon BG Hover Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box:hover .rt-icon' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'id'      => 'icon_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Icon Margin', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .rt-info-box .rt-media' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'id'      => 'icon_padding',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Icon Padding', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-media' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'icon_width',
				'mode'          => 'responsive',
				'label'   => esc_html__('Icon Width', 'sasby-core'),
				'size_units' => array('%', 'px'),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 300,
					),
					'px' => array(
						'min' => 1,
						'max' => 300,
					),
				),
				'condition'   => array('style' => array( 'style6' ) ),
				'selectors' => array(
					'{{WRAPPER}} .rt-info-item .rt-media' => 'min-width: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'mode'    => 'group',
				'type'    => \Elementor\Group_Control_Border::get_type(),
				'name'    => 'icon_border',
				'label'   => esc_html__( 'Icon Border', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-info-item .rt-media',
				'condition'   => array('style' => array( 'style6' ) ),
			),
			array(
				'mode' => 'section_end',
			),

			// Button style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_button',
				'label'   => esc_html__('Button Style', 'sasby-core'),
				'tab'     => Controls_Manager::TAB_STYLE,
			),

			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'btn_color',
				'label'   => esc_html__('Button Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .sasby-button a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .sasby-button svg path' => 'fill: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'btn_bg_color',
				'label'   => esc_html__('Button BG Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .sasby-button a' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'btn_hover_color',
				'label'   => esc_html__('Button Hover Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style6 .rt-info-item .rt-button a:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-style5 .rt-info-item .rt-button a:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-style5:hover .rt-info-item .rt-button a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .sasby-button a:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-feature-box-2:hover .sasby-button a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-feature-box-2:hover .sasby-button svg path' => 'fill: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'btn_border_color',
				'label'   => esc_html__('Button Border Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style4 .rt-button a' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .rt-feature-box-2 .btn-common:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-item .rt-button a:before' => 'background-color: {{VALUE}} !important',
				),
				'condition'   => array('style' => array( 'style2', 'style4', 'style5' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'btn_bg_hover_color',
				'label'   => esc_html__('Button BG Hover Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-style5:hover .rt-button a' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-style4 .rt-button a:hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-style4 .rt-button a:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .sasby-button a:hover' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'btn_typo',
				'label'   => esc_html__( 'Button Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .sasby-button a',
			),
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'mode'          => 'responsive',
				'size_units' => [ 'px', '%', 'em' ],
				'id'      => 'btn_padding5',
				'label'   => __( 'Button Padding', 'sasby-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-info-item .rt-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator' => 'before',
			),

			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'mode'          => 'responsive',
				'size_units' => [ 'px', '%', 'em' ],
				'id'      => 'btn_radius5',
				'label'   => __( 'Button Radius', 'sasby-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-info-item .rt-button a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			array(
				'mode'    => 'group',
				'type'    => \Elementor\Group_Control_Border::get_type(),
				'name'    => 'btn_border5',
				'label'   => esc_html__( 'Button Border', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-info-item .rt-button a',
				'condition'   => array('style' => array( 'style5' ) ),
			),

			array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'sasby-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'sasby-core' ),
					'hide'        => esc_html__( 'Off', 'sasby-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'sasby-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'sasby-core' ),
					'bounce' => esc_html__( 'bounce', 'sasby-core' ),
					'flash' => esc_html__( 'flash', 'sasby-core' ),
					'pulse' => esc_html__( 'pulse', 'sasby-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'sasby-core' ),
					'shakeX' => esc_html__( 'shakeX', 'sasby-core' ),
					'shakeY' => esc_html__( 'shakeY', 'sasby-core' ),
					'headShake' => esc_html__( 'headShake', 'sasby-core' ),
					'swing' => esc_html__( 'swing', 'sasby-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'sasby-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'sasby-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'sasby-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'sasby-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'sasby-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'sasby-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'sasby-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'sasby-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'sasby-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'sasby-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'sasby-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'sasby-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'sasby-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'sasby-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'sasby-core' ),
				'default' => '0.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'sasby-core' ),
				'default' => '1.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		switch ( $data['style'] ) {
			case 'style6':
			$template = 'rt-info-box-6';
			break;
			case 'style5':
			$template = 'rt-info-box-5';
			break;
			case 'style4':
			$template = 'rt-info-box-4';
			break;
			case 'style3':
			$template = 'rt-info-box-3';
			break;
			case 'style2':
			$template = 'rt-info-box-2';
			break;
			default:
			$template = 'rt-info-box-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}