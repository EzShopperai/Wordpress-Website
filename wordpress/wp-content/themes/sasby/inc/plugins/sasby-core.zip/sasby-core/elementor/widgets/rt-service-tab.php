<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Css_Filter;
use Elementor\Utils;
if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Service_Tab extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Service Tab', 'sasby-core' );
		$this->rt_base = 'rt-service-tab';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', array(
				'type' => \Elementor\Controls_Manager::TEXT,
				'label' => esc_html__( 'Title', 'sasby-core' ),
				'default' => esc_html__( 'Tab Title' , 'sasby-core' ),
				'label_block' => true,
            )
		);

		$repeater->add_control(
			'sub_title', array(
				'type' => \Elementor\Controls_Manager::TEXT,
				'label' => esc_html__( 'Content Title', 'sasby-core' ),
				'default' => esc_html__( 'Wiam iaculis Morbienim' , 'sasby-core' ),
				'label_block' => true,
            )
		);

		$repeater->add_control(
			'count_title', array(
				'type' => \Elementor\Controls_Manager::TEXT,
				'label' => esc_html__( 'Title Count', 'sasby-core' ),
				'default' => esc_html__( '01' , 'sasby-core' ),
				'label_block' => true,
            )
		);

		$repeater->add_control(
			'content', array(
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label' => esc_html__( 'Content', 'sasby-core' ),
				'default' => esc_html__( 'Sed ut perspiciatis unde omnis iste natus error sittery voluptatem accusantium doloremque lauda awrntiu totam rem aperiam, eaque ipsa quaed ieawr nven tore veritatis et quasi architecto' , 'sasby-core' ),
				'label_block' => true,
            )
		);
		$repeater->add_control(
            'selected_icon',[
                'label' => esc_html__( 'Icon', 'sasby-core' ),
				'type' => Controls_Manager::ICONS,
				'separator' => 'before',
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-plus',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'chevron-down',
						'angle-down',
						'angle-double-down',
						'caret-down',
						'caret-square-down',
					],
					'fa-regular' => [
						'caret-square-down',
					],
				],
				'skin' => 'inline',
				'label_block' => false,
            ]
        );

        $repeater->add_control(
			'image', array(
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__( 'Image', 'sasby-core' ),
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'description' => esc_html__( 'Recommended full image', 'sasby-core' ),
				'label_block' => true,
            )
		);
		$repeater->add_control(
			'buttontext', array(
				'type' => \Elementor\Controls_Manager::TEXT,
				'label'   => esc_html__( 'Button Text', 'sasby-core' ),
				'default' => esc_html__( 'Take Our Service', 'sasby-core' ),
				'label_block' => true,
            )
		);
		$repeater->add_control(
			'url', array(
				'type' => \Elementor\Controls_Manager::URL,
				'label' => esc_html__( 'Link (Optional)', 'sasby-core' ),
				'placeholder' => 'https://your-link.com',
				'label_block' => true,
            )
		);		

		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),

			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Layout', 'sasby-core' ),
				'options' => array(
					'layout1' => esc_html__( 'Tab Layout 1', 'sasby-core' ),
				),
				'default' => 'layout1',
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'tab_items',
				'label'   => esc_html__( 'Address', 'sasby-core' ),
				'title_field' => '{{{ title }}}',
				'fields' => $repeater->get_controls(),
				'default' => array(
					['title' => 'Power & Energy Sector', ],
					['title' => 'Explore Tiling & Painiting', ],
					['title' => 'Modern Architecture & Building', ],
				),
			),
			array(
				'mode' => 'section_end',
			),

			// Button style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_button_style',
				'label'   => esc_html__( 'Button', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition'   => array( 'layout' => array( 'layout1' ) ),
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'button_typo',
				'label'   => esc_html__( 'Button Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .tab--style--4 .nav-item .nav-link',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'button_bg_color',
				'label'   => esc_html__( 'Button BG Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .tab--style--4 .nav-item .nav-link' => 'Background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'button_hov_color',
				'label'   => esc_html__( 'Button Hover Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .tab--style--4 .nav-item .nav-link.active' => 'color: {{VALUE}}',
					'{{WRAPPER}} .tab--style--4 .nav-item .nav-link:hover' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'button_bg_hov_color',
				'label'   => esc_html__( 'Button BG Hover Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .tab--style--4 .nav-item .nav-link.active' => 'Background-color: {{VALUE}}',
					'{{WRAPPER}} .tab--style--4 .nav-item .nav-link:hover' => 'Background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'mode'          => 'responsive',
				'size_units' => [ 'px', '%', 'em' ],
				'id'      => 'button_padding',
				'label'   => __( 'Padding', 'sasby-core' ),
				'selectors' => array(
					'{{WRAPPER}} .tab--style--4 .nav-item .nav-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
				'separator' => 'before',
			),
			array(
				'mode' => 'section_end',
			),

			// Title style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_title_style',
	            'label'   => esc_html__( 'Title', 'sasby-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	            'condition'   => array( 'layout' => array( 'layout1' ) ),
	        ),
	        array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .sasby-about-tab-box .heading-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .sasby-about-tab-box .heading-title' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'sub_title_color',
				'label'   => esc_html__( 'Content Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .sasby-about-tab-box .about-list ul li' => 'color: {{VALUE}}',
				),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		switch ( $data['layout'] ) {
			case 'layout2':
			$template = 'rt-service-tab-2';
			break;
			default:
			$template = 'rt-service-tab-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}