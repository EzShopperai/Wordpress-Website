<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Work_Process extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Work Process', 'sasby-core' );
		$this->rt_base = 'rt-work-process';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'selected_icon',[
				'label' => esc_html__( 'Icon', 'sasby-core' ),
				'type' => Controls_Manager::ICONS,
				'separator' => 'before',
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-plus',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'chevron-down',
						'angle-down',
						'angle-double-down',
						'caret-down',
						'caret-square-down',
					],
					'fa-regular' => [
						'caret-square-down',
					],
				],
				'skin' => 'inline',
				'label_block' => false,
			]
		);
		$repeater->add_control(
			'title',[
				'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Title', 'sasby-core' ),
			]
		);
		$repeater->add_control(
			'content',[
				'type' => Controls_Manager::WYSIWYG,
				'label'   => esc_html__( 'Testimonials Content', 'sasby-core' ),
			]
		);

		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'works',
				'label'   => esc_html__( 'Add as many work process as you want', 'sasby-core' ),
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array('title' => 'Explore Works', 'content' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Mauris nullam the as dolor nunc semper. Ornare nulla as faucibus dum vulputate neque.“', 'rating' => 5 ),
					array('title' => 'Choose Works', 'content' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Mauris nullam the as dolor nunc semper. Ornare nulla as faucibus dum vulputate neque.“', 'rating' => 5 ),
					array('title' => 'Start Works', 'content' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Mauris nullam the as dolor nunc semper. Ornare nulla as faucibus dum vulputate neque.', 'rating' => 5 ),
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'box_border_color',
				'label'   => esc_html__( 'Icon Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing .content' => 'border-color: {{VALUE}}',
				),
			),
			array(
				'mode' => 'section_end',
			),
			// Icon style
			array(
				'mode'    => 'section_start',
				'id'      => 'general_style',
				'label'   => esc_html__( 'General Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'mode'          => 'responsive',
				'size_units' => [ 'px', '%', 'em' ],
				'id'      => 'box_margin',
				'label'   => __( 'Box Margin', 'sasby-core' ),
				'selectors' => array(
					'{{WRAPPER}} .process-list-wrap li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator' => 'before',
			),
			array(
				'mode' => 'section_end',
			),

			// Icon style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_icon',
				'label'   => esc_html__( 'Icon Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_color',
				'label'   => esc_html__( 'Icon Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing .icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .process-listing .icon svg' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_bg_color',
				'label'   => esc_html__('Icon BG Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing .icon' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_hover_color',
				'label'   => esc_html__( 'Icon Hover Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing:hover .icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .process-listing:hover .icon svg' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_bg_hover_color',
				'label'   => esc_html__('Icon BG Hover Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing:hover .icon' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'mode' => 'section_end',
			),

			// Title style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Title Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .process-listing .content .title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing .content .title' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'title_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Title Space', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .process-listing .content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'mode' => 'section_end',
			),

			// Content style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_content_style',
				'label'   => esc_html__( 'Content Style', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'content_typo',
				'label'   => esc_html__( 'Content Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .process-listing .content p',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'content_color',
				'label'   => esc_html__( 'Content Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .process-listing .content p' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'mode'          => 'responsive',
				'size_units' => [ 'px', '%', 'em' ],
				'id'      => 'box_padding',
				'label'   => __( 'Box Padding', 'sasby-core' ),
				'selectors' => array(
					'{{WRAPPER}} .process-listing .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator' => 'before',
			),
			array(
				'mode' => 'section_end',
			),

			// Animation style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_animation_style',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'sasby-core' ),
					'hide'        => esc_html__( 'Off', 'sasby-core' ),
				),
				'default' => 'wow',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'sasby-core' ),
				'options' => array(
					'none' => esc_html__( 'none', 'sasby-core' ),
					'bounce' => esc_html__( 'bounce', 'sasby-core' ),
					'flash' => esc_html__( 'flash', 'sasby-core' ),
					'pulse' => esc_html__( 'pulse', 'sasby-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'sasby-core' ),
					'shakeX' => esc_html__( 'shakeX', 'sasby-core' ),
					'shakeY' => esc_html__( 'shakeY', 'sasby-core' ),
					'headShake' => esc_html__( 'headShake', 'sasby-core' ),
					'swing' => esc_html__( 'swing', 'sasby-core' ),
					'fadeIn' => esc_html__( 'fadeIn', 'sasby-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'sasby-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'sasby-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'sasby-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'sasby-core' ),
					'bounceIn' => esc_html__( 'bounceIn', 'sasby-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'sasby-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'sasby-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'sasby-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'sasby-core' ),
					'slideInDown' => esc_html__( 'slideInDown', 'sasby-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'sasby-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'sasby-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'sasby-core' ),
				),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'sasby-core' ),
				'default' => '0.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'sasby-core' ),
				'default' => '1.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
			
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		$template = 'rt-work-process';
		return $this->rt_template( $template, $data );
	}
}