<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

use Elementor\Utils;

extract($data);
$col_class = "col-xl-{$data['col_xl']} col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-xs-{$data['col_xs']}";
?>

<div class="rt-pricing-tab">
    <?php if($data['tab_display'] == 'yes'){ ?>
    <div class="text-center">
        <ul class="nav nav-tabs" id="nav-tab" role="tablist">
            <li><button class="nav-link active" id="nav-yearly-tab" data-bs-toggle="tab" data-bs-target="#yearly" type="button" role="tab" aria-selected="true"><?php echo wp_kses_post($monthly_text); ?></button></li>
            <li><button class="nav-link" id="nav-lifetime-tab" data-bs-toggle="tab" data-bs-target="#lifetime" type="button" role="tab" aria-selected="false"><?php echo wp_kses_post($yearly_text); ?></button><?php if ($data['offer_display'] && $data['offer_text']) { ?><span class="offer"><?php echo wp_kses_post($data['offer_text']); ?></span><?php } ?></li>
        </ul>
    </div>
    <?php } ?>
    <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane rtTabFadeInUp show active" id="yearly" role="tabpanel" aria-labelledby="nav-yearly-tab">
            <div class="row g-4">
                <?php foreach ($data['feature_monthly'] as $feature_list) :
                    $attr = '';
                    if (!empty($feature_list['buttonurl']['url'])) {
                        $attr  = 'href="' . $feature_list['buttonurl']['url'] . '"';
                        $attr .= !empty($feature_list['buttonurl']['is_external']) ? ' target="_blank"' : '';
                        $attr .= !empty($feature_list['buttonurl']['nofollow']) ? ' rel="nofollow"' : '';
                    }
                ?>
                    <div class="<?php echo esc_attr($col_class); ?>">
                        <div class="rt-price-tab-box">
                            <div class="hover_bg_color" <?php if ($feature_list['hover_bg_color_month']) { ?> style="background-color: <?php echo esc_attr($feature_list['hover_bg_color_month']); ?>" <?php } ?>></div>
                            <?php if($icon_display){?>
                            <div class="item-icon">
                                <svg width="82" height="80" viewBox="0 0 104 102" fill="none" xmlns="http://www.w3.org/2000/svg" <?php if ($feature_list['icon_color_month']) { ?> style="color: <?php echo esc_attr($feature_list['icon_color_month']); ?>" <?php } ?>>
                                    <path d="M19.8402 38.5982L84.8399 38.2916M17.8836 40.5152L50.5429 82.465C50.7803 82.7714 51.085 83.0191 51.4334 83.1889C51.7818 83.3588 52.1647 83.4461 52.5523 83.4443C52.9399 83.4425 53.3219 83.3515 53.6687 83.1784C54.0155 83.0053 54.3178 82.7547 54.5523 82.4461L86.8145 40.1902C87.1317 39.7731 87.3145 39.2694 87.3385 38.7459C87.3626 38.2225 87.2267 37.7042 86.9491 37.2598L75.8544 19.5384C75.626 19.1717 75.3076 18.8694 74.9295 18.6603C74.5514 18.4513 74.1261 18.3423 73.694 18.3439L30.7974 18.5462C30.3653 18.5487 29.9411 18.6617 29.565 18.8743C29.1888 19.0869 28.8733 19.3922 28.6484 19.761L17.7213 37.5863C17.4479 38.0333 17.3169 38.5529 17.3459 39.0761C17.3749 39.5992 17.5624 40.1012 17.8836 40.5152Z" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M74.7574 20.8389L67.34 38.3741M67.34 38.3741L52.2458 18.445L37.3403 38.5156M67.34 38.3741L52.5406 80.9443L37.3403 38.5156M29.7579 21.0511L37.3403 38.5156" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </div>
                            <?php } ?>

                            <div class="price-header">
                                <h3 class="rt-title"><?php echo wp_kses_post($feature_list['title']); ?></h3>
                                <?php if (!empty($feature_list['subtitle'])) { ?>
                                    <div class="desc"><?php echo wp_kses_post($feature_list['subtitle']); ?></div>
                                <?php } ?>
                                <h4 class="rt-price">
                                    <?php if (!empty($feature_list['offer_price'])) { ?>
                                        <del><?php echo esc_html__('Regularly', 'sasby-core'); ?> <?php echo wp_kses_post($feature_list['price']); ?></del>
                                        <?php echo wp_kses_post($feature_list['offer_price']); ?><span class="price-unit"><?php echo wp_kses_post($feature_list['unit']); ?></span>
                                    <?php } else { ?>
                                        <?php echo wp_kses_post($feature_list['price']); ?><span class="price-unit"><?php echo wp_kses_post($feature_list['unit']); ?></span>
                                    <?php } ?>
                                </h4>
                                <?php
                                if ($feature_list['offer_price'] && $feature_list['price']) {
                                    $reg_price = explode('$', $feature_list['price']);
                                    $offer_price = explode('$', $feature_list['offer_price']);
                                    $reg_price_slice = $reg_price[1];
                                    $offer_price_slice = $offer_price[1];
                                    $discounted_price = ((100 / $reg_price_slice) * ($reg_price_slice -  $offer_price_slice));
                                }
                                ?>
                                <?php if ($feature_list['offer_price'] && $feature_list['price']) { ?><div class="save-price"><?php echo esc_html__('Save', 'sasby-core'); ?> <?php echo floor($discounted_price); ?>%</div><?php } ?>
                            </div>
                            <div class="rt-price-button">
                                <a <?php echo $attr; ?> class="btn-common" <?php if ($feature_list['btn_hover_color_month']) { ?> style="color: <?php echo esc_attr($feature_list['btn_hover_color_month']); ?>" <?php } ?>>
                                    <?php echo esc_html($feature_list['buttontext']); ?>
                                </a>
                            </div>
                            <div class="rt-features"><?php echo wp_kses_post($feature_list['text']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="tab-pane rtTabFadeInUp" id="lifetime" role="tabpanel" aria-labelledby="nav-lifetime-tab">
            <div class="row g-4">
                <?php foreach ($data['feature_yearly'] as $feature_list2) :
                    $attr2 = '';
                    if (!empty($feature_list2['buttonurl2']['url'])) {
                        $attr2  = 'href="' . $feature_list2['buttonurl2']['url'] . '"';
                        $attr2 .= !empty($feature_list2['buttonurl2']['is_external']) ? ' target="_blank"' : '';
                        $attr2 .= !empty($feature_list2['buttonurl2']['nofollow']) ? ' rel="nofollow"' : '';
                    }
                ?>
                    <div class="<?php echo esc_attr($col_class); ?>">
                        <div class="rt-price-tab-box">
                            <div class="hover_bg_color" <?php if ($feature_list2['hover_bg_color_year']) { ?> style="background-color: <?php echo esc_attr($feature_list2['hover_bg_color_year']); ?>" <?php } ?>></div>
                            <div class="item-icon">
                                <svg width="82" height="80" viewBox="0 0 104 102" fill="none" xmlns="http://www.w3.org/2000/svg" <?php if ($feature_list2['icon_color_year']) { ?> style="color: <?php echo esc_attr($feature_list2['icon_color_year']); ?>" <?php } ?>>
                                    <path d="M19.8402 38.5982L84.8399 38.2916M17.8836 40.5152L50.5429 82.465C50.7803 82.7714 51.085 83.0191 51.4334 83.1889C51.7818 83.3588 52.1647 83.4461 52.5523 83.4443C52.9399 83.4425 53.3219 83.3515 53.6687 83.1784C54.0155 83.0053 54.3178 82.7547 54.5523 82.4461L86.8145 40.1902C87.1317 39.7731 87.3145 39.2694 87.3385 38.7459C87.3626 38.2225 87.2267 37.7042 86.9491 37.2598L75.8544 19.5384C75.626 19.1717 75.3076 18.8694 74.9295 18.6603C74.5514 18.4513 74.1261 18.3423 73.694 18.3439L30.7974 18.5462C30.3653 18.5487 29.9411 18.6617 29.565 18.8743C29.1888 19.0869 28.8733 19.3922 28.6484 19.761L17.7213 37.5863C17.4479 38.0333 17.3169 38.5529 17.3459 39.0761C17.3749 39.5992 17.5624 40.1012 17.8836 40.5152Z" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M74.7574 20.8389L67.34 38.3741M67.34 38.3741L52.2458 18.445L37.3403 38.5156M67.34 38.3741L52.5406 80.9443L37.3403 38.5156M29.7579 21.0511L37.3403 38.5156" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </div>
                            <div class="price-header">
                                <h3 class="rt-title"><?php echo wp_kses_post($feature_list2['title2']); ?></h3>
                                <?php if (!empty($feature_list2['subtitle2'])) { ?>
                                    <div class="desc"><?php echo wp_kses_post($feature_list2['subtitle2']); ?></div>
                                <?php } ?>
                                <h4 class="rt-price">
                                    <?php if (!empty($feature_list2['offer_price2'])) { ?>
                                        <del><?php echo esc_html__('Regularly', 'sasby-core'); ?> <?php echo wp_kses_post($feature_list2['price2']); ?></del>
                                        <?php echo wp_kses_post($feature_list2['offer_price2']); ?><span class="price-unit"><?php echo wp_kses_post($feature_list2['unit2']); ?></span>
                                    <?php } else { ?>
                                        <?php echo wp_kses_post($feature_list2['price2']); ?><span class="price-unit"><?php echo wp_kses_post($feature_list2['unit2']); ?></span>
                                    <?php } ?>
                                </h4>
                                <?php
                                if ($feature_list2['offer_price2']) {
                                    $reg_price2 = explode('$', $feature_list2['price2']);
                                    $offer_price2 = explode('$', $feature_list2['offer_price2']);
                                    $reg_price_slice2 = $reg_price2[1];
                                    $offer_price_slice2 = $offer_price2[1];
                                    $discounted_price2 = ((100 / $reg_price_slice2) * ($reg_price_slice2 -  $offer_price_slice2));
                                }
                                ?>
                                <?php if ($feature_list2['offer_price2']) { ?><div class="save-price"><?php echo esc_html__('Save', 'sasby-core'); ?> <?php echo floor($discounted_price2); ?>%</div><?php } ?>
                            </div>
                            <div class="rt-price-button">
                                <a <?php echo $attr2; ?> class="btn-common" <?php if ($feature_list2['btn_hover_color_year']) { ?> style="color: <?php echo esc_attr($feature_list2['btn_hover_color_year']); ?>" <?php } ?>>
                                    <?php echo esc_html($feature_list2['buttontext2']); ?>
                                </a>
                            </div>
                            <div class="rt-features"><?php echo wp_kses_post($feature_list2['text2']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php if ($data['note_display'] == 'yes' && $data['note_desc']) { ?><div class="price-note"><?php echo esc_html($data['note_desc']); ?></div><?php } ?>
</div>