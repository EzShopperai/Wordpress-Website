<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

add_action( 'widgets_init', 'sasby_widgets_init' );
function sasby_widgets_init() {
	// Register Custom Widgets
	register_widget( 'SasbyTheme_About_Widget' );
	register_widget( 'SasbyTheme_Address_Widget' );
	register_widget( 'SasbyTheme_Social_Widget' );
	register_widget( 'SasbyTheme_Post_Box' );
	register_widget( 'SasbyTheme_Post_Tab' );
	register_widget( 'SasbyTheme_Feature_Post' );
	register_widget( 'SasbyTheme_Product_Box' );
	register_widget( 'SasbyTheme_Category_Widget' );
	register_widget( 'SasbyTheme_Download_Widget' );
	register_widget( 'SasbyTheme_Contact_Widget' );
}