<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Group_Control_Image_Size;

if ($data['mobile_frame']['url']) {
	$sasby_bg = 'url(' . $data['mobile_frame']['url'] . ')';
} else {
	$sasby_img_url = SASBY_ASSETS_URL . 'img/screenshot.png';
	$sasby_bg = 'url(' . $sasby_img_url . ')';
}

?>
<div class="screenshot-wrapper">
	<div class="screenshot-inner-slider rt-swiper-nav swiper">
		<div class="mobile-frame" style="background-image: <?php echo esc_html($sasby_bg); ?>">


		</div>
		<div class="swiper-wrapper">
			<?php foreach ($data['showcase-screenshots'] as $screenshot) { ?>
				<div class="swiper-slide">
					<div class="screenshot-box">
						<div class="item-img">
							<?php echo wp_get_attachment_image($screenshot['image']['id'], 'full'); ?>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
		<div class="swiper-pagination"></div>
	</div>
</div>