<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit;

class Content_Toggle extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Content toggle', 'sasby-core' );
    $this->rt_base = 'rt-content-toggle';
    parent::__construct( $data, $args );
  }
  public function get_post_template( $type = 'page' ) {
    $posts = get_posts(
      array(
        'post_type'      => 'elementor_library',
        'orderby'        => 'title',
        'order'          => 'ASC',
        'posts_per_page' => '-1',
        'tax_query'      => array(
          array(
            'taxonomy' => 'elementor_library_type',
            'field'    => 'slug',
            'terms'    => $type,
          ),
        ),
      )
    );
    $templates = array();
    foreach ( $posts as $post ) {
      $templates[] = array(
        'id'   => $post->ID,
        'name' => $post->post_title,
      );
    }
    return $templates;
  }
  public function get_saved_data( $type = 'section' ) {
    $saved_widgets = $this->get_post_template( $type );
    $options[-1]   = __( 'Select', 'sasby-core' );
    if ( count( $saved_widgets ) ) {
      foreach ( $saved_widgets as $saved_row ) {
        $options[ $saved_row['id'] ] = $saved_row['name'];
      }
    } else {
      $options['no_template'] = __( 'It seems that, you have not saved any template yet.', 'sasby-core' );
    }
    return $options;
  }
  public function get_content_type() {
    $content_type = array(
      'content'              => __( 'Content', 'sasby-core' ),
      'saved_rows'           => __( 'Saved Section', 'sasby-core' ),
      'saved_page_templates' => __( 'Saved Page', 'sasby-core' ),
    );
    return $content_type;
  }
  public function rt_fields(){

    $repeater = new \Elementor\Repeater();
    $repeater->add_control(
      'tab_title',
      array(
        'type' => \Elementor\Controls_Manager::TEXT,
        'label' => esc_html__('Title', 'sasby-core'),
        'default' => esc_html__('Tab Title', 'sasby-core'),
        'label_block' => true,
      )
    );
    $repeater->add_control(
      'selected_icon',
      [
        'label' => esc_html__('Icon', 'sasby-core'),
        'type' => Controls_Manager::ICONS,
        'separator' => 'before',
        'fa4compatibility' => 'icon',
        'default' => [
          'value' => 'fas fa-plus',
          'library' => 'fa-solid',
        ],
        'recommended' => [
          'fa-solid' => [
            'chevron-down',
            'angle-down',
            'angle-double-down',
            'caret-down',
            'caret-square-down',
          ],
          'fa-regular' => [
            'caret-square-down',
          ],
        ],
        'skin' => 'inline',
        'label_block' => false,
      ]
    );
    $repeater->add_control(
      'tab_content',
        array(
          'type'    => Controls_Manager::SELECT2,
          'label'   => esc_html__('Select Template', 'sasby-core'),
          'options' => $this->get_saved_data('section'),
          'default' => 'key',
        )
    );
	$repeater->add_control(
	  'select_color',
	  [
		  'type' => Controls_Manager::SELECT2,
		  'label'   => esc_html__('Select Color', 'sasby-core'),
		  'options' => array(
			  'select-color' => esc_html__( 'Select Color', 'sasby-core' ),
			  'sky-blue' => esc_html__( 'Sky Blue', 'sasby-core' ),
			  'royal-blue' => esc_html__( 'Royal Blue', 'sasby-core' ),
			  'orange' => esc_html__( 'Orange', 'sasby-core' ),
			  'purple' => esc_html__( 'Purple', 'sasby-core' ),
		  ),
		  'default' => 'select-color',
	  ]
    );

    $fields = array(
        array(
            'mode'    => 'section_start',
            'id'      => 'title_tabl',
            'label'   => esc_html__( 'Title', 'sasby-core' ),
        ),
        array(
            'type'    => Controls_Manager::REPEATER,
            'id'      => 'tab_items',
            'label'   => esc_html__('Tab List', 'sasby-core'),
            'title_field' => '{{{ tab_title }}}',
            'fields' => $repeater->get_controls(),
            'default' => array(
              ['title' => 'Tab Template',],
            ),
        ),

        array(
            'mode' => 'section_end',
        ),
       
        /*title section*/
        array(
            'mode'    => 'section_start',
            'id'      => 'sec_style',
            'label'   => esc_html__( 'Style', 'sasby-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,
        ),

        array(
          'mode'    => 'group',
          'type'    => Group_Control_Typography::get_type(),
          'name'    => 'title_typo',
          'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
          'selector' => '{{WRAPPER}} .faq-nav-wrapper .nav .nav-link',
        ),
        


      // Tab For Normal view.
			array(
				'mode' => 'tabs_start',
				'id'   => 'meta_tabs_start',
			),			
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_1',
				'label' => esc_html__( 'Normal', 'sasby-core' ),
			),
			
			array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title Color', 'sasby-core' ),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .faq-nav-wrapper .nav .nav-link' => 'color: {{VALUE}}',
        ),
      ),
      array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'icon_color',
        'label'   => esc_html__('Icon Color', 'sasby-core'),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .nav-item .nav-link .icon i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .nav-item .nav-link .icon svg path' => 'fill: {{VALUE}}',
        ),
      ),
      array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'icon_bg_color',
        'label'   => esc_html__('Icon BG Color', 'sasby-core'),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .nav-item .nav-link .icon' => 'background-color: {{VALUE}}',
        ),
      ),
      array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'border_Color',
        'label'   => esc_html__( 'Border Color', 'sasby-core' ),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .tab--style--3 .nav-tabs' => 'border-color: {{VALUE}}',
        ),
      ),

			array(
				'mode' => 'tab_end',
			),
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_2',
				'label' => esc_html__( 'Active', 'sasby-core' ),
			),

			array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_active_color',
        'label'   => esc_html__( 'Title Color', 'sasby-core' ),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .faq-nav-wrapper .nav .nav-link.active' => 'color: {{VALUE}}',
        ),
      ),
      array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'icon_active_color',
        'label'   => esc_html__('Icon Color', 'sasby-core'),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .nav-item .nav-link.active .icon i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .nav-item .nav-link.active .icon svg path' => 'fill: {{VALUE}}',
        ),
      ),
      array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'icon_bg_active_color',
        'label'   => esc_html__('Icon Active BG Color', 'sasby-core'),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .nav-item .nav-link.active .icon' => 'background-color: {{VALUE}}',
        ),
      ),
      array(
        'type'    => Controls_Manager::COLOR,
        'id'      => 'border_active_Color',
        'label'   => esc_html__( 'Border Color', 'sasby-core' ),
        'default' => '',
        'selectors' => array(
          '{{WRAPPER}} .tab--style--3 .nav-tabs .nav-item .nav-link::before' => 'background-color: {{VALUE}}',
        ),
      ),
		
			array(
				'mode' => 'tab_end',
			),
			array(
				'mode' => 'tabs_end',
			),
      array(
        'mode' => 'section_end',
      ),
      
    );
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    $template = 'content-toggle';
    return $this->rt_template( $template, $data );
  }
}
