<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
use Elementor\Icons_Manager;

extract($data);

if (!isset($data['icon']) && !Icons_Manager::is_migration_allowed()) {
	$data['icon'] = 'fa fa-plus';
	$data['icon_align'] = $this->get_settings('icon_align');
}
$is_new = empty($data['icon']) && Icons_Manager::is_migration_allowed();
$has_icon = (!$is_new || !empty($testimonial['selected_icon']['value']));
 ?>
<ul class="process-list-wrap">
    <?php
        $m = $data['delay'];
        $n = $data['duration'];
    ?>
    <?php foreach ($data['works'] as $work) { ?>
    <li class="<?php echo esc_attr($data['animation']); ?> <?php echo esc_attr($data['animation_effect']); ?>" data-wow-delay="<?php echo esc_attr($m); ?>s" data-wow-duration="<?php echo esc_attr($n); ?>s">
        <div class="process-listing d-flex">
	        <?php if($work['selected_icon']){ ?>
            <div class="icon">
	            <?php Icons_Manager::render_icon($work['selected_icon']); ?>
            </div>
            <?php } ?>
            <div class="content">
                <?php if($work['title']){ ?>
                <h3 class="title"><?php echo wp_kses_post($work['title']); ?></h3>
                <?php } ?>
	            <?php if($work['content']){ ?>
                <p class="mb-0">
                    <?php echo wp_kses_post($work['content']);?>
                </p>
                <?php } ?>
            </div>
        </div>
    </li>
    <?php $m = $m + 0.2; $n = $n + 0.1; } ?>
</ul>