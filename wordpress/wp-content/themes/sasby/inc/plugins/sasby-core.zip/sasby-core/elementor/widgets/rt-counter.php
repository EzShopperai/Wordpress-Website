<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Counter extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = __( 'RT Counter', 'sasby-core' );
		$this->rt_base = 'rt-counter';
		parent::__construct( $data, $args );
	}

	private function rt_load_scripts(){
		wp_enqueue_script( 'counterup' );
		wp_enqueue_script( 'waypoints' );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Counter Layout', 'sasby-core' ),
				'options' => array(
					'style1' => esc_html__( 'Layout 01' , 'sasby-core' ),
					'style2' => esc_html__( 'Layout 02' , 'sasby-core' ),
					'style3' => esc_html__( 'Layout 03' , 'sasby-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'    => 'responsive',
				'label'   => esc_html__( 'Alignment', 'sasby-core' ),
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item' => 'text-align: {{VALUE}};',
				),
				'condition'   => array( 'style' => array( 'style1' ) ),
			),

			array(
				'type'    => Controls_Manager::SWITCHER,
				'id'      => 'showhide',
				'label'   => esc_html__( 'Icon', 'sasby-core' ),
				'label_on'    => esc_html__( 'Show', 'sasby-core' ),
				'label_off'   => esc_html__( 'Hide', 'sasby-core' ),
				'default'     => 'no',
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'icon_class',
				'label'   => esc_html__( 'Icon', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'sasby-core' ),
				'default' => esc_html__( 'Experiences', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'number',
				'label'   => esc_html__( 'Counter Number', 'sasby-core' ),
				'default' => 25,
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'number_prefix',
				'label'   => esc_html__( 'Number Prefix', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'after_text',
				'label'   => esc_html__( 'Counter Unit', 'sasby-core' ),
				'default' => esc_html__( '+', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration_text',
				'label'   => esc_html__('Duration', 'sasby-core'),
				'default' => esc_html__('Per Month', 'sasby-core'),
				'condition'   => array('style' => array('style1')),
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'duration_icon',
				'label'   => esc_html__('Duration Icon', 'sasby-core'),
				'default' => array(
					'value' => 'fas fa-smile-wink',
					'library' => 'fa-solid',
				),
				'condition'   => array('style' => array('style1')),
			),
			
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'speed',
				'label'   => esc_html__( 'Animation Speed', 'sasby-core' ),
				'default' => 5000,
				'description' => esc_html__( 'The total duration of the count animation in milisecond eg. 5000', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'steps',
				'label'   => esc_html__( 'Animation Steps', 'sasby-core' ),
				'default' => 10,
				'description' => esc_html__( 'Counter steps eg. 10', 'sasby-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'item_divider',
				'label'       => esc_html__( 'Item Divider', 'sasby-core' ),
				'label_on'    => esc_html__( 'Show', 'sasby-core' ),
				'label_off'   => esc_html__( 'Hide', 'sasby-core' ),
				'default'     => 'yes',
				'condition'   => array( 'style!' => array( 'style1' ) ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'item_angle',
				'label'       => esc_html__( 'Item Angle', 'sasby-core' ),
				'label_on'    => esc_html__( 'Show', 'sasby-core' ),
				'label_off'   => esc_html__( 'Hide', 'sasby-core' ),
				'default'     => 'no',
				'condition'   => array( 'style' => array( 'style1' ) ),
			),
			array(
				'mode' => 'section_end',
			),
			// Box Style
			array(
				'mode'    => 'section_start',
				'id'      => 'bg_style',
				'label'   => esc_html__( 'Box background', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition'   => array( 'style' => array( 'style1' ) ),
			),
			array(
				'type'    => Controls_Manager::SWITCHER,
				'id'      => 'bg_showhide',
				'label'   => esc_html__( 'Box Background Color', 'sasby-core' ),
				'label_on'    => esc_html__( 'Show', 'sasby-core' ),
				'label_off'   => esc_html__( 'Hide', 'sasby-core' ),
				'default'     => 'yes',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'box_bg',
				'label'   => esc_html__( 'Box Background Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-counter-style1 .item-angle:after' => 'background-color: {{VALUE}}',
				),
				'condition'   => array( 'bg_showhide' =>'yes' ),
			),	
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_padding',
	            'label'   => __( 'Box Padding', 'sasby-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-counter-box .rt-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',                    
	            ),
	        ),
	        array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_radius',
	            'label'   => __( 'Radius', 'sasby-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-counter-box .rt-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',                    
	            ),
	        ),
			array(
				'mode' => 'section_end',
			),
			// Title Style
			array(
				'mode'    => 'section_start',
				'id'      => 'title_style',
				'label'   => esc_html__( 'Title', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-counter-box .rt-item .rt-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .rt-title' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'title_space',
				'mode'          => 'responsive',
				'label'   => esc_html__('Title Space', 'sasby-core'),
				'size_units' => array('%', 'px'),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .rt-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'mode' => 'section_end',
			),
			// Counter Style
			array(
				'mode'    => 'section_start',
				'id'      => 'counter_style',
				'label'   => esc_html__( 'Counter', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'counter_typo',
				'label'   => esc_html__( 'Counter Style', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-counter-box .rt-item .counter-number',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'counter_color',
				'label'   => esc_html__( 'Counter Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .counter-number' => 'color: {{VALUE}}',
				),
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'unit_typo',
				'label'   => esc_html__( 'Unit Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-counter-box .rt-item .counter-unit',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'unite_color',
				'label'   => esc_html__( 'Unit Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .counter-unit' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'counter_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Counter Space', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-counter-box .rt-item .counter-number' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'mode' => 'section_end',
			),
			// Duration Text Style
			array(
				'mode'    => 'section_start',
				'id'      => 'duration_style',
				'label'   => esc_html__('Duration', 'sasby-core'),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'duration_typo',
				'label'   => esc_html__('Duration Typo', 'sasby-core'),
				'selector' => '{{WRAPPER}} .rt-counter-box .rt-item .duration',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'duration_color',
				'label'   => esc_html__('Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .duration' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'duration_icon_color',
				'label'   => esc_html__('Color', 'sasby-core'),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .duration svg' => 'color: {{VALUE}}',
				),
			),
			array(
				'mode' => 'section_end',
			),
			// Icon Style
			array(
				'mode'    => 'section_start',
				'id'      => 'icon_style',
				'label'   => esc_html__( 'Icon', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_color',
				'label'   => esc_html__( 'Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .rt-media i' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_bg_color',
				'label'   => esc_html__( 'Background Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-style2 .rt-item .rt-media i' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-counter-style3 .rt-item .rt-media i' => 'background-color: {{VALUE}}',
				),
				'condition'   => array( 'style!' => array( 'style1' ) ),
			),	
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'icon_size',
				'mode'    => 'responsive',
				'label'   => esc_html__( 'Font Size', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-counter-box .rt-item .rt-media i' => 'font-size: {{VALUE}}px',
				),
			),
	        array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'icon_radius',
	            'label'   => __( 'Radius', 'sasby-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-counter-box .rt-item .rt-media i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',                    
	            ),
				'condition'   => array( 'style!' => array( 'style1' ) ),
	        ),
			array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'sasby-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'sasby-core' ),
					'hide'        => esc_html__( 'Off', 'sasby-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'sasby-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'sasby-core' ),
					'bounce' => esc_html__( 'bounce', 'sasby-core' ),
					'flash' => esc_html__( 'flash', 'sasby-core' ),
					'pulse' => esc_html__( 'pulse', 'sasby-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'sasby-core' ),
					'shakeX' => esc_html__( 'shakeX', 'sasby-core' ),
					'shakeY' => esc_html__( 'shakeY', 'sasby-core' ),
					'headShake' => esc_html__( 'headShake', 'sasby-core' ),
					'swing' => esc_html__( 'swing', 'sasby-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'sasby-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'sasby-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'sasby-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'sasby-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'sasby-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'sasby-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'sasby-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'sasby-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'sasby-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'sasby-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'sasby-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'sasby-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'sasby-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'sasby-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'sasby-core' ),
				'default' => '0.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'sasby-core' ),
				'default' => '1.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		$this->rt_load_scripts();
		
		switch ( $data['style'] ) {
			case 'style3':
			$template = 'rt-counter-3';
			break;
			case 'style2':
			$template = 'rt-counter-2';
			break;
			default:			
			$template = 'rt-counter-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}

}