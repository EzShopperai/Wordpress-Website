<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Showcase_Screenshot extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__('RT Showcase Screenshot', 'sasby-core' );
		$this->rt_base = 'rt-showcase-screenshot';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'image',
			[
				'type' => Controls_Manager::MEDIA,
				'label'   => esc_html__('Apps Screenshot', 'sasby-core'),
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			]
		);
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'mobile_frame',
				'label'   => esc_html__('Mobile Frame Cover Image', 'sasby-core'),
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'showcase-screenshots',
				'label'   => esc_html__('Add as many apps screenshot as you want', 'sasby-core'),
				'fields' => $repeater->get_controls(),
			),
			array(
				'mode' => 'section_end',
			),
			/*Box section*/
		);
		return $fields;
	}

	protected function render()
	{
		$data = $this->get_settings();
		$template = 'rt-showcase-screenshot';
		return $this->rt_template($template, $data);
	}
}