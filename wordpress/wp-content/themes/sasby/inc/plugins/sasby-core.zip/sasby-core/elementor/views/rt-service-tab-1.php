<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
use Elementor\Icons_Manager;
use SasbyTheme;
use SasbyTheme_Helper;
use \WP_Query;
extract($data);
$thumb_size = 'sasby-size5';

if ( ! isset( $data['icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
    $data['icon'] = 'fa fa-plus';
    $data['icon_align'] = $this->get_settings( 'icon_align' );
}
?>

<div class="sasby-about-tab-box">
    <div class="tab--style--4">
        <div class="row">
            <div class="col-xl-5 col-lg-8">
                <ul class="nav nav-tabs" role="tablist">
	                <?php $i = 1;
	                    foreach ( $data['tab_items'] as $tab_item_list ) { ?>
                        <li class="nav-item">
                            <a class="nav-link <?php if ( $i == 1 ) { ?>active<?php } ?>" data-bs-toggle="tab" data-bs-target="#tab_<?php echo esc_html( $i ); ?>" href="#tab_<?php echo esc_html( $i ); ?>"><?php echo wp_kses_post( $tab_item_list['title'] ); ?></a>
                        </li>
                    <?php $i++; } ?>
                </ul>
            </div>
        </div>
        <div class="tab-content" id="myTabContent">
	        <?php $i = 1;
	        foreach ( $data['tab_items'] as $tab_item_list ) {
	        if( $tab_item_list['image']['id'] ) {
		        $image_class = 'image';
	        } else {
		        $image_class = 'noimage';
	        }
	        ?>
            <div class="tab-pane animate__fadeInUp animate__animated <?php if ( $i == 1 ) { ?>active<?php } ?> show" id="tab_<?php echo esc_html( $i ); ?>" role="tabpanel">
                <div class="row justify-content-between">
                    <div class="col-xl-5 col-lg-6">
                        <div class="text-box">
                            <h3 class="heading-title"><?php echo wp_kses_post( $tab_item_list['sub_title'] ); ?></h3>
                            <div class="about-list">
                                <?php echo wp_kses_post( $tab_item_list['content'] ); ?>
                            </div>
                        </div>
                    </div>
                    <?php if( !empty( $tab_item_list['image']['id'] ) ) { ?>
                        <div class="col-xl-6 col-lg-6">
                            <div class="about-tab-image-layout d-flex">
                                <div class="item-img"><?php echo wp_get_attachment_image( $tab_item_list['image']['id'], 'full' ); ?></div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <?php $i++; } ?>
        </div>
    </div>
</div>
