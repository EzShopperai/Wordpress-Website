<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use SasbyTheme;
use SasbyTheme_Helper;
use \RT_Postmeta;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Postmeta' ) ) {
	return;
}

$Postmeta = RT_Postmeta::getInstance();

$prefix = SASBY_CORE_CPT_PREFIX;

/*-------------------------------------
#. Layout Settings
---------------------------------------*/
$nav_menus = wp_get_nav_menus( array( 'fields' => 'id=>name' ) );
$nav_menus = array( 'default' => __( 'Default', 'sasby-core' ) ) + $nav_menus;
$sidebars  = array( 'default' => __( 'Default', 'sasby-core' ) ) + SasbyTheme_Helper::custom_sidebar_fields();

$Postmeta->add_meta_box( "{$prefix}_page_settings", __( 'Layout Settings', 'sasby-core' ), array( 'page', 'post', 'sasby_team', 'sasby_portfolio', 'product' ), '', '', 'high', array(
	'fields' => array(
	
		"{$prefix}_layout_settings" => array(
			'label'   => __( 'Layouts', 'sasby-core' ),
			'type'    => 'group',
			'value'  => array(	
			
				"{$prefix}_layout" => array(
					'label'   => __( 'Layout', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default'       => __( 'Default', 'sasby-core' ),
						'full-width'    => __( 'Full Width', 'sasby-core' ),
						'left-sidebar'  => __( 'Left Sidebar', 'sasby-core' ),
						'right-sidebar' => __( 'Right Sidebar', 'sasby-core' ),
					),
					'default'  => 'default',
				),		
				'sasby_sidebar' => array(
					'label'    => __( 'Custom Sidebar', 'sasby-core' ),
					'type'     => 'select',
					'options'  => $sidebars,
					'default'  => 'default',
				),
				"{$prefix}_page_menu" => array(
					'label'    => __( 'Main Menu', 'sasby-core' ),
					'type'     => 'select',
					'options'  => $nav_menus,
					'default'  => 'default',
				),
				"{$prefix}_header_opt" => array(
					'label' 	  => __( 'Header On/Off', 'sasby-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'on'      => __( 'Enabled', 'sasby-core' ),
						'off'     => __( 'Disabled', 'sasby-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_tr_header" => array(
					'label'    	  => __( 'Transparent Header', 'sasby-core' ),
					'type'     	  => 'select',
					'options'  	  => array(
						'default' => __( 'Default', 'sasby-core' ),
						'on'      => __( 'Enabled', 'sasby-core' ),
						'off'     => __( 'Disabled', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_header" => array(
					'label'   => __( 'Header Layout', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'1'       => __( 'Layout 1', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_header_bg_color" => array(
					'label' => __( 'Header Background Color', 'sasby-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),
				"{$prefix}_header_width" => array(
					'label' 	  => __('Header Width', 'sasby-core'),
					'type'  	  => 'select',
					'options' => array(
						'default' => __('Default', 'sasby-core'),
						'off'      => __('Container', 'sasby-core'),
						'on'     => __('Full Width Container', 'sasby-core'),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_cutom_logo" => array(
					'label' => __('Header Logo', 'sasby-core'),
					'type'  => 'image',
					'desc'  => __('If not selected, default will be used', 'sasby-core'),
				),
				"{$prefix}_cutom_sticky_logo" => array(
					'label' => __('Header Sticky Logo', 'docfi-core'),
					'type'  => 'image',
					'desc'  => __('If not selected, default will be used', 'docfi-core'),
				),
				"{$prefix}_footer_cta" => array(
					'label' 	  => __('Footer CTA', 'tripfery-core'),
					'type'  	  => 'select',
					'options' => array(
						'default' => __('Default', 'tripfery-core'),
						'on'      => __('Enabled', 'tripfery-core'),
						'off'     => __('Disabled', 'tripfery-core'),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_footer" => array(
					'label'   => __( 'Footer Layout', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'1'       => __( 'Layout 1', 'sasby-core' ),
						'2'       => __( 'Layout 2', 'sasby-core' ),
						'3'       => __( 'Layout 3', 'sasby-core' ),
						'4'       => __( 'Layout 4', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_footer_area" => array(
					'label' 	  => __( 'Footer Area', 'sasby-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'on'      => __( 'Enabled', 'sasby-core' ),
						'off'     => __( 'Disabled', 'sasby-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_footer_bgcolor" => array(
					'label' => __('Footer Background Color', 'tripfery-core'),
					'type'  => 'color_picker',
					'desc'  => __('If not selected, default will be used', 'tripfery-core'),
				),
				"{$prefix}_copyright_area" => array(
					'label' 	  => __( 'Copyright Area', 'sasby-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'on'      => __( 'Enabled', 'sasby-core' ),
						'off'     => __( 'Disabled', 'sasby-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_top_padding" => array(
					'label'   => __( 'Content Padding Top', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'0px'     => __( '0px', 'sasby-core' ),
						'10px'    => __( '10px', 'sasby-core' ),
						'20px'    => __( '20px', 'sasby-core' ),
						'30px'    => __( '30px', 'sasby-core' ),
						'40px'    => __( '40px', 'sasby-core' ),
						'50px'    => __( '50px', 'sasby-core' ),
						'60px'    => __( '60px', 'sasby-core' ),
						'70px'    => __( '70px', 'sasby-core' ),
						'80px'    => __( '80px', 'sasby-core' ),
						'90px'    => __( '90px', 'sasby-core' ),
						'100px'   => __( '100px', 'sasby-core' ),
						'110px'   => __( '110px', 'sasby-core' ),
						'120px'   => __( '120px', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_bottom_padding" => array(
					'label'   => __( 'Content Padding Bottom', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'0px'     => __( '0px', 'sasby-core' ),
						'10px'    => __( '10px', 'sasby-core' ),
						'20px'    => __( '20px', 'sasby-core' ),
						'30px'    => __( '30px', 'sasby-core' ),
						'40px'    => __( '40px', 'sasby-core' ),
						'50px'    => __( '50px', 'sasby-core' ),
						'60px'    => __( '60px', 'sasby-core' ),
						'70px'    => __( '70px', 'sasby-core' ),
						'80px'    => __( '80px', 'sasby-core' ),
						'90px'    => __( '90px', 'sasby-core' ),
						'100px'   => __( '100px', 'sasby-core' ),
						'110px'   => __( '110px', 'sasby-core' ),
						'120px'   => __( '120px', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_banner" => array(
					'label'   => __( 'Banner', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'on'	  => __( 'Enable', 'sasby-core' ),
						'off'	  => __( 'Disable', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_breadcrumb" => array(
					'label'   => __( 'Breadcrumb', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'on'      => __( 'Enable', 'sasby-core' ),
						'off'	  => __( 'Disable', 'sasby-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_banner_type" => array(
					'label'   => __( 'Banner Background Type', 'sasby-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'sasby-core' ),
						'bgimg'   => __( 'Background Image', 'sasby-core' ),
						'bgcolor' => __( 'Background Color', 'sasby-core' ),
					),
					'default' => 'default',
				),
				"{$prefix}_banner_bgimg" => array(
					'label' => __( 'Banner Background Image', 'sasby-core' ),
					'type'  => 'image',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),
				"{$prefix}_banner_bgcolor" => array(
					'label' => __( 'Banner Background Color', 'sasby-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),		
				"{$prefix}_page_bgimg" => array(
					'label' => __( 'Page/Post Background Image', 'sasby-core' ),
					'type'  => 'image',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),
				"{$prefix}_border_radius" => array(
					'label'   => __('Button Border Radius', 'sasby-core'),
					'type'    => 'select',
					'options' => array(
						'default'       => __('Default', 'sasby-core'),
						'1'       => __('0px', 'sasby-core'),
						'5'       => __('5px', 'sasby-core'),
						'10'       => __('10px', 'sasby-core'),
						'20'       => __('20px', 'sasby-core'),
						'30'       => __('30px', 'sasby-core'),
					),
					'default'  => 'default',
				),
				"{$prefix}_btn_color" => array(
					'label' => __( 'Button Color', 'sasby-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),
				"{$prefix}_btn_hover_color" => array(
					'label' => __( 'Button Hover Color', 'sasby-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),
				"{$prefix}_page_bgcolor" => array(
					'label' => __( 'Page/Post Background Color', 'sasby-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'sasby-core' ),
				),
				"{$prefix}_primary_color" => array(
					'label' => __('Primary Color', 'sasby-core'),
					'type'  => 'color_picker',
					'desc'  => __('If not selected, default will be used', 'sasby-core'),
				),
				"{$prefix}_secondary_color" => array(
					'label' => __('Secondary Color', 'sasby-core'),
					'type'  => 'color_picker',
					'desc'  => __('If not selected, default will be used', 'sasby-core'),
				),
			)
		)
	),
) );

/*-------------------------------------
#. Single Post Gallery
---------------------------------------*/
$Postmeta->add_meta_box( 'sasby_post_info', __( 'Post Info', 'sasby-core' ), array( 'post' ), '', '', 'high', array(
	'fields' => array(
		"sasby_youtube_link" => array(
			'label'   => __( 'Youtube Link', 'sasby-core' ),
			'type'    => 'text',
			'default'  => '',
			'desc'  => __( 'Only work for the video post format', 'sasby-core' ),
		),
		'sasby_post_gallery' => array(
			'label' => __( 'Post Gallery', 'sasby-core' ),
			'type'  => 'gallery',
			'desc'  => __( 'Only work for the gallery post format', 'sasby-core' ),
		),
	),
) );

/*-------------------------------------
#. Team
---------------------------------------*/
$Postmeta->add_meta_box( 'sasby_team_settings', __( 'Team Member Settings', 'sasby-core' ), array( 'sasby_team' ), '', '', 'high', array(
	'fields' => array(
		'sasby_team_position' => array(
			'label' => __( 'Position', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_team_website' => array(
			'label' => __( 'Website', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_team_email' => array(
			'label' => __( 'Email', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_team_phone' => array(
			'label' => __( 'Phone', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_team_address' => array(
			'label' => __( 'Address', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_team_socials_header' => array(
			'label' => __( 'Socials', 'sasby-core' ),
			'type'  => 'header',
			'desc'  => __( 'Enter your social links here', 'sasby-core' ),
		),
		'sasby_team_socials' => array(
			'type'  => 'group',
			'value'  => SasbyTheme_Helper::team_socials()
		),
	)
) );

$Postmeta->add_meta_box( 'sasby_team_skills', __( 'Team Member Skills', 'sasby-core' ), array( 'sasby_team' ), '', '', 'high', array(
	'fields' => array(
		'sasby_team_skill_info' => array(
			'label' => __( 'Skill Info', 'sasby-core' ),
			'type'  => 'textarea',
		),
		'sasby_team_skill' => array(
			'type'  => 'repeater',
			'button' => __( 'Add New Skill', 'sasby-core' ),
			'value'  => array(
				'skill_name' => array(
					'label' => __( 'Skill Name', 'sasby-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. Marketing', 'sasby-core' ),
				),
				'skill_value' => array(
					'label' => __( 'Skill Percentage (%)', 'sasby-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. 75', 'sasby-core' ),
				),
				'skill_color' => array(
					'label' => __( 'Skill Color', 'sasby-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, primary color will be used', 'sasby-core' ),
				),
			)
		),
	)
) );
$Postmeta->add_meta_box( 'sasby_team_contact', __( 'Team Member Contact', 'sasby-core' ), array( 'sasby_team' ), '', '', 'high', array(
	'fields' => array(
		'sasby_team_contact_form' => array(
			'label' => __( 'Contct Shortcode', 'sasby-core' ),
			'type'  => 'text',
		),
	)
) );

/*-------------------------------------
#. Portfolio
---------------------------------------*/
$Postmeta->add_meta_box( 'sasby_portfolio_info', __( 'Portfolio Project Information', 'sasby-core' ), array( 'sasby_portfolio' ), '', '', 'high', array(
	'fields' => array(
		'sasby_portfolio_style' => array(
			'label'   => __( 'Portfolio Single Style', 'sasby-core' ),
			'type'    => 'select',
			'options' => array(
				'default'  => __( 'Default', 'sasby-core' ),
				'1'  => __( 'Style One', 'sasby-core' ),
				'2'  => __( 'Style Two', 'sasby-core' ),
			),
			'default'  => 'default',
		),

		'sasby_project_title' => array(
			'label' => __( 'Project Title', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_project_text' => array(
			'label' => __( 'Project Text', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_project_client' => array(
			'label' => __( 'Project Client', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_project_start' => array(
			'label' => __( 'Project Start', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_project_end' => array(
			'label' => __( 'Project End', 'sasby-core' ),
			'type'  => 'text',
		),
		'sasby_project_web' => array(
			'label' => __( 'Project Web', 'sasby-core' ),
			'type'  => 'text',
			'default'  => '',
		),				
		'sasby_project_rating' => array(
			'label' => __( 'Select the Rating', 'sasby-core' ),
			'type'  => 'select',
			'options' => array(
				'-1' => __( 'Default', 'sasby-core' ),
				'1'    => '1',
				'2'    => '2',
				'3'    => '3',
				'4'    => '4',
				'5'    => '5'
				),
			'default'  => '-1',
		),

		'sasby_project_Test_f' => array(
			'label' => __( 'Project Test', 'sasby-core' ),
			'type'  => 'text',
		),
	)
) );


/*-------------------------------------
#. WooCommerce
---------------------------------------*/
$Postmeta->add_meta_box( 'sasby_woo_product', __( 'Product Background', 'sasby-core' ), array( 'product' ), '', '', 'high', array(
	'fields' => array(
		'sasby_product_bgc' => array(
			'label' => __( 'Product Background Color', 'sasby-core' ),
			'type'  => 'color_picker',
		),
	)
) );