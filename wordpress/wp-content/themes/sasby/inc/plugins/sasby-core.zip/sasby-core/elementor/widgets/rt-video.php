<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Video extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Video', 'sasby-core' );
		$this->rt_base = 'rt-video';
		parent::__construct( $data, $args );
	}
	
	private function rt_load_scripts(){
		wp_enqueue_script( 'magnific-popup' );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'sasby-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Video Style', 'sasby-core' ),
				'options' => array(
					'style1' => esc_html__( 'Video Style 1' , 'sasby-core' ),
					'style2' => esc_html__( 'Video Style 2', 'sasby-core' ),
					'style3' => esc_html__( 'Video Style 3', 'sasby-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'video_layout',
				'label'   => esc_html__( 'Play Button', 'sasby-core' ),				
				'options' => array(
					'play-btn-primary' 		=> esc_html__( 'Play Primary', 'sasby-core' ),
					'play-btn-white' 	 	=> esc_html__( 'Play White', 'sasby-core' ),
					'play-btn-white-lg' 	=> esc_html__( 'Play White-lg', 'sasby-core' ),
					'play-btn-transparent' 	=> esc_html__( 'Play transparent', 'sasby-core' ),
				),
				'default' => 'play-btn-white',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'video_title',
				'label'   => esc_html__( 'Video Title', 'sasby-core' ),
				'default' => esc_html__( 'Watch Our Presentation!', 'sasby-core' ),
				'condition'   => array( 'style!' => array( 'style3' ) ),
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'videourl',
				'label'   => esc_html__( 'Video URL', 'sasby-core' ),
				'placeholder' => 'https://your-link.com',
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'video_image',
				'label'   => esc_html__( 'Image', 'sasby-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'sasby-core' ),
				'condition'   => array( 'style!' => array( 'style3' ) ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'sasby-core' ),	
				'name' => 'icon_image_size', 
				'separator' => 'none',
				'condition'   => array( 'style!' => array( 'style3' ) ),
			),			
			array(
				'mode' => 'section_end',
			),
			/*Box section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'video_button_style',
	            'label'   => esc_html__( 'Box Style', 'sasby-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	            'condition'   => array( 'style!' => array( 'style3' ) ),
	        ),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'sasby-core' ),
				'selector' => '{{WRAPPER}} .rt-video-layout .rt-video .video-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-video-layout .rt-video .video-title' => 'color: {{VALUE}}',
				),
			),

			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'bag_color',
				'label'   => esc_html__( 'Image Overlay Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-video-layout .rt-video .rt-img:after' => 'background-color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'border_width',
	            'label'   => __( 'Border Width', 'sasby-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-video-style1 .rt-video .rt-img img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                  
	            ),
	            'separator' => 'before',
	            'condition'   => array( 'style' => array( 'style1' ) ),
	        ),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'border_color',
				'label'   => esc_html__( 'Border Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-video-style1 .rt-video .rt-img img' => 'background-color: {{VALUE}}',
				),
				'condition'   => array( 'style' => array( 'style1' ) ),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_radius',
	            'label'   => __( 'Box Radius', 'sasby-core' ),                 
	            'selectors' => array(                  
	                '{{WRAPPER}} .rt-video-layout .rt-video .rt-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                  
	                '{{WRAPPER}} .rt-video-layout .rt-video .rt-img:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                  
	                '{{WRAPPER}} .rt-video-style1 .rt-video .rt-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Image Blend', 'sasby-core' ),	
				'name' => 'blend', 
				'selector' => '{{WRAPPER}} img',		
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'image_height',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Image Height', 'sasby-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 1000,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-video-layout .rt-video .rt-img img' => 'height: {{SIZE}}{{UNIT}};',
				),
			),
	        array(
				'mode' => 'section_end',
			),


			// Icon style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_icon_style',
				'label'   => esc_html__( 'Icon', 'sasby-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'video_icon_color',
				'label'   => esc_html__( 'Icon Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-video-layout .icon-sasby-play' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'video_icon_bg_color',
				'label'   => esc_html__( 'Icon BG Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-video-layout .rt-play' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'video_icon_border_color',
				'label'   => esc_html__( 'Icon Border Color', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .play-btn-white::before' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .play-btn-white::after' => 'border-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'icon_width',
				'mode'          => 'responsive',
				'label'   => esc_html__('Icon Width', 'sasby-core'),
				'size_units' => array('%', 'px'),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-play' => 'width: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'icon_height',
				'mode'          => 'responsive',
				'label'   => esc_html__('Icon Height', 'sasby-core'),
				'size_units' => array('%', 'px'),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-play' => 'height: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'icon_size',
				'label'   => esc_html__( 'Icon Size', 'sasby-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-play' => 'font-size: {{VALUE}}px',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'border_height1',
				'mode'          => 'responsive',
				'label'   => esc_html__('Icon Border Width & Height 1', 'sasby-core'),
				'size_units' => array('%', 'px'),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 200,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-play::after' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} a.rt-play::after' => 'width: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'border_height2',
				'mode'          => 'responsive',
				'label'   => esc_html__('Icon Border Width & Height 2', 'sasby-core'),
				'size_units' => array('%', 'px'),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 200,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-play::before' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} a.rt-play::before' => 'width: {{SIZE}}{{UNIT}};',
				),
			),
	        array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'sasby-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'sasby-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'sasby-core' ),
					'hide'        => esc_html__( 'Off', 'sasby-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'sasby-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'sasby-core' ),
					'bounce' => esc_html__( 'bounce', 'sasby-core' ),
					'flash' => esc_html__( 'flash', 'sasby-core' ),
					'pulse' => esc_html__( 'pulse', 'sasby-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'sasby-core' ),
					'shakeX' => esc_html__( 'shakeX', 'sasby-core' ),
					'shakeY' => esc_html__( 'shakeY', 'sasby-core' ),
					'headShake' => esc_html__( 'headShake', 'sasby-core' ),
					'swing' => esc_html__( 'swing', 'sasby-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'sasby-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'sasby-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'sasby-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'sasby-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'sasby-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'sasby-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'sasby-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'sasby-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'sasby-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'sasby-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'sasby-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'sasby-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'sasby-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'sasby-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'sasby-core' ),
				'default' => '0.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'sasby-core' ),
				'default' => '1.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		$this->rt_load_scripts();

		switch ( $data['style'] ) {
			case 'style3':
			$template = 'rt-video-3';
			break;
			case 'style2':
			$template = 'rt-video-2';
			break;
			default:
			$template = 'rt-video-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}