<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Sasby_Core;
use Elementor\Icons_Manager;

extract($data); ?>

<div class="tab--style--3">
	<ul class="nav nav-tabs" role="tablist">
		<?php
			$i = 1;
			foreach ($data['tab_items'] as $tab_list) { ?>
			<li class="nav-item <?php echo esc_attr($tab_list['select_color']); ?>">
				<button class="nav-link d-flex align-items-center <?php if($i==1){ echo "active"; } ?>" id="al_<?php echo esc_attr($i); ?>" data-bs-toggle="pill" data-bs-target="#targetid_<?php echo esc_attr($i); ?>" type="button" role="tab" aria-selected="true">
					<?php if($tab_list['selected_icon']){ ?>
						<span class="icon">
							<?php Icons_Manager::render_icon($tab_list['selected_icon']); ?>
						</span>
					<?php } ?>
					<?php if ($tab_list['tab_title']) { ?>
						<span class="title mb-0"><?php echo esc_html($tab_list['tab_title']); ?></span>
					<?php } ?>	
				</button>
			</li>
			<?php $i++; }
		?>	
	</ul>
	<div class="tab-content" id="myTabContent2">
		<?php
		$i = 1;
		foreach ($data['tab_items'] as $tab_list) { ?>
			<div class="tab-pane fade <?php if ($i == 1) {
				echo "active show";
				} ?>" id="targetid_<?php echo esc_attr($i); ?>" role="tabpanel">
				<?php $content = \Elementor\Plugin::$instance->frontend->get_builder_content_for_display($tab_list['tab_content']);
				print($content);
				?>
			</div>
		<?php $i++;	}
		?>
	</div>
</div>